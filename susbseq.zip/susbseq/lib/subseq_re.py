def paas(a)
	print a